// function menuList() {
//   const filterByFirstLetterButton = document.getElementById('filterByFirstLetter');
//   const sortByPopulationButton = document.getElementById('sortByPopulation');
//   const showLikedCountriesButton = document.getElementById('showLikedCountries');

//   const sortCountries = () => {
//     const sortedCountries = countries.sort((a, b) => b.population - a.population);
//     cards.innerHTML = '';
//     sortedCountries.forEach(country => createCard(country));
//   }

//   sortCountries();

//   sortByPopulationButton.addEventListener('click', () => {
//     sortByPopulation();
//   });

//   showLikedCountriesButton.addEventListener('click', () => {
//     // פונקציה להצגת מדינות מועדפות
//   });
// }

// export default menuList;
