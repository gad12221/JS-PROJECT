# Name
Gadi Alkalay

# The College where I study

HackerU 

# My Knowledge

HTML5,CSS, Sass, Bootstrap, Javascript


# Responsive-personal_portfolio
This portfolio contains the code for my personal portfolio website built using HTML, CSS, Bootstrap, Sass. The portfolio showcases my skills, projects, and accomplishments.

